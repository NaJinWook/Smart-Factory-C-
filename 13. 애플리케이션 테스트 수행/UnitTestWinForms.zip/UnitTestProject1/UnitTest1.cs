﻿using System;
using System.Data.SqlClient;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using UnitTestWinForms;

namespace UnitTestProject1
{
    [TestClass]
    public class DataBase
    {
        private SqlConnection conn;
        public bool status = false;
        public int status2 = -1;

        public DataBase()
        {
            status = Connection();
            status2 = ConnectionClose();
        }

        public bool Connection()
        {
            string host = "(localdb)\\ProjectsV13";
            string user = "root";
            string password = "1234";
            string db = "gdc";
            string connStr = string.Format("server={0};uid={1};password={2};database={3}", host, user, password, db);
            SqlConnection conn = new SqlConnection(connStr);

            try
            {
                conn.Open();
                this.conn = conn;
                //MessageBox.Show("MS-SQL 연결 성공!");
                return true;
            }
            catch
            {
                conn.Close();
                this.conn = null;
                //MessageBox.Show("MS-SQL 연결 실패!");
                return false;
            }
        }

        public int ConnectionClose()
        {
            try
            {
                conn.Close();
                //MessageBox.Show("MS-SQL 연결끊기 성공!");
                return 1;
            }
            catch
            {
                //MessageBox.Show("MS-SQL 연결끊기 실패!");
                return -1;
            }
        }

        public bool NonQuery(string sql)
        {
            try
            {
                if (status)
                {
                    SqlCommand comm = new SqlCommand(sql, conn);
                    comm.ExecuteNonQuery();
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch
            {
                return false;
            }
        }

        public SqlDataReader Reader(string sql)
        {
            try
            {
                if (status)
                {
                    SqlCommand comm = new SqlCommand(sql, conn);
                    return comm.ExecuteReader();
                }
                else
                {
                    return null;
                }
            }
            catch
            {
                return null;
            }
        }

        public void ReaderClose(SqlDataReader reader)
        {
            reader.Close();
        }

        [TestMethod]
        public void DB_Connecttion() // DB 연결 접속 확인
        {
            Assert.AreEqual(true, status);
        }

        [TestMethod]
        public void DB_ConnectionClose() // DB 연결 끊기 테스트
        {
            Assert.AreEqual(1, status2);
        }
    }

    [TestClass]
    public class CRUD
    {
        SqlDataReader sdr;
        DataBase db = new DataBase();
        int count = 0;

        public CRUD()
        {
            count = DB_Select();
        }

        public int DB_Select()
        {
            db.Connection();

            string sql = "select mNo, mID, mPass, mName, delYn, regDate, modDate from Member;";
            sdr = db.Reader(sql);
            while (sdr.Read())
            {
                string[] arr = new string[sdr.FieldCount];
                for (int i = 0; i < sdr.FieldCount; i++)
                {
                    arr[i] = sdr.GetValue(i).ToString();
                }
                count++;
            }
            db.ReaderClose(sdr);
            return count;
        }

        [TestMethod]
        public void DB_Select_Test()
        {
            Assert.AreEqual(8, count);
        }

        public bool InsertData()
        {
            try
            {
                string sql = string.Format("insert into Member (mID, mPass, mName) values ('test_id','test_pwd','test_name');");
                db.NonQuery(sql);
                DB_Select();
                Console.WriteLine("insert 성공");
                return true;
            }
            catch
            {
                return false;
            }
        }

        [TestMethod]
        public void DB_Insert()
        {
            Assert.AreEqual(true, InsertData());
        }
    }
}

