﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form2 : Form
    {
        DB db = new DB();
        public Form2()
        {
            InitializeComponent();
            Load += Form2_Load;
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            button1.Click += Button1_Click;
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            string sql = string.Format("insert into exam(Title, Content, Name, Passwd) values('{0}', '{1}', '{2}', '{3}');", textBox1.Text, textBox2.Text, textBox3.Text, textBox4.Text);
            db.NonQuery(sql);     
            this.Close();
        }
    }
}
