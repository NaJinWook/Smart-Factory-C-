﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        DB db = new DB();
        string select = "sp_select;";
        public Form1()
        {
            InitializeComponent();
            Load += Form1_Load;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            button1.Click += Button1_Click;
            listView1.MouseClick += ListView1_MouseClick;
            listView1.FullRowSelect = true;
            main(select);
        }

        private void ListView1_MouseClick(object sender, MouseEventArgs e)
        {
            
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            Form2 f2 = new Form2();
            f2.ShowDialog();
        }


        public void main(string sql)
        {
            MySqlDataReader sdr = db.Reader(sql);
            listView1.Items.Clear();
            while (sdr.Read())
            {
                string[] arr = new string[sdr.FieldCount];
                for (int i = 0; i < sdr.FieldCount; i++)
                {
                    arr[i] = sdr.GetValue(i).ToString();
                }
                listView1.Items.Add(new ListViewItem(arr));
            }
            db.ReaderClose(sdr);
            
        }
    }
}
