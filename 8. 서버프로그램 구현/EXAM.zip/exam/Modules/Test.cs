using System;
using System.Collections;
using MySql.Data.MySqlClient;

namespace WebAPI2.Modules
{
    public class Test
    {
        public string mNo { set; get; }
        public string nNo { set; get; }
        public string nTitle { set; get; }
        public string nContents { set; get; }
    }
    public static class Query
    {
        public static ArrayList GetInsert(Test test)
        {
            MYsql my = new MYsql();
            string sql = string.Format("insert into Notice (nTitle, nContents, mNo) values ('{0}','{1}','{2}');", test.nTitle, test.nContents, test.mNo);
            if(my.NonQuery(sql))
            {
                return GetSelect();
            }
            else
            {
                return new ArrayList();
            }
        }
        public static ArrayList GetUpdate(Test test)
        {
            MYsql my = new MYsql();
            string sql = string.Format("update Notice set nTitle = '{0}', nContents = '{1}' where nNo = '{2}' and mNo = '{3}';", test.nTitle, test.nContents, test.nNo, test.mNo);
            if(my.NonQuery(sql))
            {
                return GetSelect();
            }
            else
            {
                return new ArrayList();
            }

        }

        public static ArrayList GetDelete(Test test)
        {
            MYsql my = new MYsql();
            string sql = string.Format("Update Notice set delYn = 'Y' where nNo = '{0}' and mNo = '{1}';",test.nNo, test.mNo);
            if(my.NonQuery(sql))
            {
                return GetSelect();
            }
            else
            {
                return new ArrayList();
            }
        }

        public static ArrayList GetSelect()
        {
            MYsql my = new MYsql();
            string sql = "select n.mNo, n.nTitle, n.nContents, m.mName, DATE_FORMAT(n.regDate, '%Y-%m-%d') as regDate, DATE_FORMAT(n.modDate, '%Y-%m-%d') as modDate from Notice as n inner join Member as m on (n.mNo = m.mNo and m.delYn = 'N') where n.delYn = 'N';";
            MySqlDataReader sdr = my.Reader(sql);
            string result = "";
            ArrayList list = new ArrayList();
            while(sdr.Read())
            {
                Hashtable ht = new Hashtable();
                for(int i = 0; i < sdr.FieldCount; i++)
                {
                    //result += string.Format("{0} : {1} ", sdr.GetName(i), sdr.GetValue(i));
                    ht.Add(sdr.GetName(i), sdr.GetValue(i));
                }
                //result += "\n";
                list.Add(ht);
            }
            return list;
        }
    }
}